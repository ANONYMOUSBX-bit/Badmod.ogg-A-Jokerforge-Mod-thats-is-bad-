SMODS.Seal {
    key = 'deadseal',
    pos = { x = 0, y = 0 },
    badge_colour = HEX('000000'),
   loc_txt = {
        name = 'Dead Seal',
        label = 'Dead Seal',
        text = {
        [1] = 'Create a {C:enhanced}Negative{} {C:spectral}Spectral{} card',
        [2] = 'when scored',
        [3] = '{C:red}Destroy{} this card after scoring'
    }
    },
    atlas = 'CustomSeals',
    unlocked = true,
    discovered = true,
    no_collection = false,
    calculate = function(self, card, context)
        if context.destroy_card and context.cardarea == G.play and context.destroy_card == card and card.should_destroy then
            G.E_MANAGER:add_event(Event({
                func = function()
                    card:start_dissolve()
                    return true
                end
            }))
            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Card Destroyed!", colour = G.C.RED})
            return
        end
        if context.main_scoring and context.cardarea == G.play then
            card.should_destroy = false
            local created_consumable = true
                G.E_MANAGER:add_event(Event({
                    func = function()
                        SMODS.add_card{set = 'Spectral', edition = 'e_negative', key_append = 'enhanced_card_spectral'}
                        return true
                    end
                }))
            card.should_destroy = true
            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = created_consumable and "+1 Consumable!" or nil, colour = G.C.SECONDARY_SET.Spectral})
        end
    end
}