SMODS.Seal {
    key = 'gamblersseal',
    pos = { x = 1, y = 0 },
    config = {
        extra = {
            odds = 4
        }
    },
    badge_colour = HEX('DC143C'),
   loc_txt = {
        name = 'Gamblers Seal',
        label = 'Gamblers Seal',
        text = {
        [1] = '{C:green}1 in 4{} chance to',
        [2] = 'create 2 {C:red}Gambling{}',
        [3] = 'cards when {C:attention}discarded{}'
    }
    },
    atlas = 'CustomSeals',
    unlocked = true,
    discovered = true,
    no_collection = false,
    calculate = function(self, card, context)
        if context.discard and context.other_card == card then
            if SMODS.pseudorandom_probability(card, 'group_0_782709c5', 1, card.ability.seal.extra.odds, 'm_badmodog_gamblersseal') then
                SMODS.calculate_effect({func = function()local created_consumable = false
                if #G.consumeables.cards + G.GAME.consumeable_buffer < G.consumeables.config.card_limit then
                    created_consumable = true
                    G.GAME.consumeable_buffer = G.GAME.consumeable_buffer + 1
                    G.E_MANAGER:add_event(Event({
                        func = function()
                            SMODS.add_card{set = 'gambling', key_append = 'enhanced_card_gambling'}
                            G.GAME.consumeable_buffer = 0
                            return true
                        end
                    }))
                end
                    if created_consumable then
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+1 Consumable!", colour = G.C.PURPLE})
                    end
                    return true
                end}, card)
                SMODS.calculate_effect({func = function()local created_consumable = false
                if #G.consumeables.cards + G.GAME.consumeable_buffer < G.consumeables.config.card_limit then
                    created_consumable = true
                    G.GAME.consumeable_buffer = G.GAME.consumeable_buffer + 1
                    G.E_MANAGER:add_event(Event({
                        func = function()
                            SMODS.add_card{set = 'gambling', key_append = 'enhanced_card_gambling'}
                            G.GAME.consumeable_buffer = 0
                            return true
                        end
                    }))
                end
                    if created_consumable then
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+1 Consumable!", colour = G.C.PURPLE})
                    end
                    return true
                end}, card)
            end
        end
    end
}