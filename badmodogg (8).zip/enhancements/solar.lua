SMODS.Enhancement {
    key = 'solar',
    pos = { x = 1, y = 0 },
    config = {
        extra = {
            discardsremaining = 0,
            x_mult = 0.9
        }
    },
    loc_txt = {
        name = 'Solar',
        text = {
        [1] = '{C:attention}Retrigger{} this card once',
        [2] = 'for every discard',
        [3] = 'remaining',
        [4] = 'This card gives {X:red,C:white}X0.9{} Mult'
    }
    },
    atlas = 'CustomEnhancements',
    any_suit = false,
    replace_base_card = false,
    no_rank = false,
    no_suit = false,
    always_scores = false,
    unlocked = true,
    discovered = true,
    no_collection = false,
    weight = 5,
    calculate = function(self, card, context)
        if context.repetition and card.should_retrigger then
            return { repetitions = card.ability.extra.retrigger_times }
        end
        if context.main_scoring and context.cardarea == G.play then
            card.should_retrigger = false
            card.should_retrigger = true
            card.ability.extra.retrigger_times = G.GAME.current_round.discards_left
            SMODS.calculate_effect({x_mult = card.ability.extra.x_mult}, card)
        end
    end
}