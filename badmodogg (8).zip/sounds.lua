SMODS.Sound{
    key="holymoly_sound",
    path="holymoly_sound.ogg",
    pitch=0.7,
    volume=0.6
}