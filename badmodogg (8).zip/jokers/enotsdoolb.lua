SMODS.Joker{ --Enotsdoolb
    key = "enotsdoolb",
    config = {
        extra = {
            pb_x_mult_ed8a6413 = 0.2,
            perma_x_mult = 0
        }
    },
    loc_txt = {
        ['name'] = 'Enotsdoolb',
        ['text'] = {
            [1] = 'tluM {X:red,C:white}2.0X{} niag yltnenamrep',
            [2] = '{C:hearts}straeH{} deyalP'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 3,
        y = 2
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 17,
    rarity = "badmodog_amazing",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if context.other_card:is_suit("Hearts") then
                context.other_card.ability.perma_x_mult = context.other_card.ability.perma_x_mult or 0
                context.other_card.ability.perma_x_mult = context.other_card.ability.perma_x_mult + card.ability.extra.pb_x_mult_ed8a6413
                return {
                    extra = { message = localize('k_upgrade_ex'), colour = G.C.MULT }, card = card
                }
            end
        end
    end
}