SMODS.Joker{ --Cash Register
    key = "cashregister",
    config = {
        extra = {
            sell_value = 1
        }
    },
    loc_txt = {
        ['name'] = 'Cash Register',
        ['text'] = {
            [1] = 'This Joker gains {C:money}$1{}',
            [2] = 'in sell value when a',
            [3] = 'Joker or consumable',
            [4] = 'is {C:attention}sold{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 1,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 1,
    blueprint_compat = false,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.selling_card  then
                return {
                    func = function()
            card.ability.extra_value = (card.ability.extra_value or 0) + card.ability.extra.sell_value
            card:set_cost()
                    return true
                end,
                    message = "*cash register noises*"
                }
        end
    end
}