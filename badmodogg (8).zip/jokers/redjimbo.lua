SMODS.Joker{ --Red Jimbo
    key = "redjimbo",
    config = {
        extra = {
            mult = 0,
            chips = 0
        }
    },
    loc_txt = {
        ['name'] = 'Red Jimbo',
        ['text'] = {
            [1] = 'This joker gains {C:red}+0.5{} Mult and {C:blue}+4{} Chips',
            [2] = 'when a {C:attention}discard{} is used',
            [3] = '{C:inactive}(Currently{} {C:mult}+#1#{} {C:inactive}Mult and{} {C:chips}+#2#{} {C:inactive}Chips)'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 1,
        y = 6
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.mult, card.ability.extra.chips}}
    end,

    calculate = function(self, card, context)
        if context.pre_discard  then
                return {
                    func = function()
                    card.ability.extra.mult = (card.ability.extra.mult) + 0.5
                    return true
                end,
                    extra = {
                        func = function()
                    card.ability.extra.chips = (card.ability.extra.chips) + 4
                    return true
                end,
                        colour = G.C.GREEN
                        }
                }
        end
        if context.cardarea == G.jokers and context.joker_main  then
                return {
                    chips = card.ability.extra.chips,
                    extra = {
                        mult = card.ability.extra.mult
                        }
                }
        end
    end
}