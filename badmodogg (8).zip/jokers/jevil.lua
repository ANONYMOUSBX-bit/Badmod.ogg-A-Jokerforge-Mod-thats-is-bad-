SMODS.Joker{ --Jevil
    key = "jevil",
    config = {
        extra = {
            repetitions = 1,
            chips = 10,
            mult = 5,
            dollars = 1,
            Xmult = 1.1,
            xchips = 1.25
        }
    },
    loc_txt = {
        ['name'] = 'Jevil',
        ['text'] = {
            [1] = 'Played {C:attention}cards{} give {C:mult}+5{} Mult,',
            [2] = '{C:chips}+10{} Chips, {X:red,C:white}X1.1{} Mult,',
            [3] = '{X:blue,C:white}X1.25{} Chips {}and {C:money}$1{}',
            [4] = '{C:attention}Retriggers{} all played cards',
            [5] = 'once',
            [6] = '{C:purple}CHAOS, CHAOS!{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 3,
        y = 4
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 20,
    rarity = 4,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    soul_pos = {
        x = 4,
        y = 4
    },
    in_pool = function(self, args)
          return (
          not args 
          or args.source ~= 'sho' 
           
          )
          and true
      end,

    calculate = function(self, card, context)
        if context.repetition and context.cardarea == G.play  then
                return {
                    repetitions = card.ability.extra.repetitions,
                    message = "Chaos, Chaos!"
                }
        end
        if context.individual and context.cardarea == G.play  then
                return {
                    chips = card.ability.extra.chips,
                    extra = {
                        mult = card.ability.extra.mult,
                        extra = {
                            dollars = card.ability.extra.dollars,
                            colour = G.C.MONEY,
                        extra = {
                            Xmult = card.ability.extra.Xmult,
                        extra = {
                            x_chips = card.ability.extra.xchips,
                            colour = G.C.DARK_EDITION
                        }
                        }
                        }
                        }
                }
        end
    end
}