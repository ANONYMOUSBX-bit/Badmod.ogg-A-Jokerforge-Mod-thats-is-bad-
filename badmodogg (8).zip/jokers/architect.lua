SMODS.Joker{ --Architect
    key = "architect",
    config = {
        extra = {
        }
    },
    loc_txt = {
        ['name'] = 'Architect',
        ['text'] = {
            [1] = 'Add {C:attention}2{} {C:attention}Red{} Seal {C:attention}Steel{}',
            [2] = 'Kings to your hand when',
            [3] = 'blind is {C:attention}selected'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 4,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 19,
    rarity = "badmodog_amazing",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    soul_pos = {
        x = 5,
        y = 0
    },

    calculate = function(self, card, context)
        if context.setting_blind  then
                return {
                    func = function()
                local card_front = pseudorandom_element({G.P_CARDS.S_K, G.P_CARDS.H_K, G.P_CARDS.D_K, G.P_CARDS.C_K}, pseudoseed('add_card_hand_suit'))
                local new_card = create_playing_card({
                    front = card_front,
                    center = G.P_CENTERS.m_steel
                }, G.discard, true, false, nil, true)
            new_card:set_seal("Red", true)
                
                G.playing_card = (G.playing_card and G.playing_card + 1) or 1
                new_card.playing_card = G.playing_card
                table.insert(G.playing_cards, new_card)
                
                G.E_MANAGER:add_event(Event({
                    func = function()
                        G.hand:emplace(new_card)
                        new_card:start_materialize()
                        SMODS.calculate_context({ playing_card_added = true, cards = { new_card } })
                        return true
                    end
                }))
            end,
                    message = "Added Card to Hand!",
                    extra = {
                        func = function()
                local card_front = pseudorandom_element({G.P_CARDS.S_K, G.P_CARDS.H_K, G.P_CARDS.D_K, G.P_CARDS.C_K}, pseudoseed('add_card_hand_suit'))
                local new_card = create_playing_card({
                    front = card_front,
                    center = G.P_CENTERS.m_steel
                }, G.discard, true, false, nil, true)
            new_card:set_seal("Red", true)
                
                G.playing_card = (G.playing_card and G.playing_card + 1) or 1
                new_card.playing_card = G.playing_card
                table.insert(G.playing_cards, new_card)
                
                G.E_MANAGER:add_event(Event({
                    func = function()
                        G.hand:emplace(new_card)
                        new_card:start_materialize()
                        SMODS.calculate_context({ playing_card_added = true, cards = { new_card } })
                        return true
                    end
                }))
            end,
                            message = "Added Card to Hand!",
                        colour = G.C.GREEN
                        }
                }
        end
    end
}