SMODS.Joker{ --Electronic Arts
    key = "electronicarts",
    config = {
        extra = {
            dollars = 3,
            respect = 0
        }
    },
    loc_txt = {
        ['name'] = 'Electronic Arts',
        ['text'] = {
            [1] = 'Create a {C:attention}Loot Box{} when',
            [2] = 'Blind is {C:attention}selected{} and',
            [3] = 'lose {C:red}-$3'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 0,
        y = 2
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.setting_blind  then
                return {
                    func = function()
            local created_joker = false
    if #G.jokers.cards + G.GAME.joker_buffer < G.jokers.config.card_limit then
        created_joker = true
        G.GAME.joker_buffer = G.GAME.joker_buffer + 1
            G.E_MANAGER:add_event(Event({
                func = function()
                    local joker_card = SMODS.add_card({ set = 'Joker', key = 'j_badmodog_lootbox' })
                    if joker_card then
                        
                        
                    end
                    G.GAME.joker_buffer = 0
                    return true
                end
            }))
            end
            if created_joker then
                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+1 Loot Box", colour = G.C.BLUE})
            end
            return true
        end,
                    extra = {
                        dollars = -card.ability.extra.dollars,
                        colour = G.C.MONEY
                        }
                }
        end
    end
}