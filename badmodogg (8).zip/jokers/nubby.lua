SMODS.Joker{ --Nubby
    key = "nubby",
    config = {
        extra = {
            levelups = 1
        }
    },
    loc_txt = {
        ['name'] = 'Nubby',
        ['text'] = {
            [1] = 'When {C:attention}hand{} is played,',
            [2] = '{C:attention}level{} it up by {C:attention}#1#{}',
            [3] = 'Increase the value',
            [4] = 'of {C:attention} level ups{} by {C:attention}1{}',
            [5] = 'at the {C:attention}end of the round{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 7,
        y = 5
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 75,
    rarity = "badmodog_absurd",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = false,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    soul_pos = {
        x = 8,
        y = 5
    },

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.levelups}}
    end,

    calculate = function(self, card, context)
        if context.end_of_round and context.game_over == false and context.main_eval  then
                return {
                    func = function()
                    card.ability.extra.levelups = (card.ability.extra.levelups) + 1
                    return true
                end
                }
        end
        if context.cardarea == G.jokers and context.joker_main  then
                target_hand = (context.scoring_name or "High Card")
                return {
                    level_up = card.ability.extra.levelups,
      level_up_hand = target_hand,
                    message = localize('k_level_up_ex')
                }
        end
    end
}