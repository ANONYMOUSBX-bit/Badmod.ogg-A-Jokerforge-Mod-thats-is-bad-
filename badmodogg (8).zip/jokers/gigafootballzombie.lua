SMODS.Joker{ --Giga-Football Zombie
    key = "gigafootballzombie",
    config = {
        extra = {
            slot_change = 4,
            xchips = 1,
            xmult = 1,
            consumablesheld = 1
        }
    },
    loc_txt = {
        ['name'] = 'Giga-Football Zombie',
        ['text'] = {
            [1] = 'Played {C:spades}Black Cards{} gain a {C:attention}Dead Seal{}',
            [2] = 'This Joker gains {X:blue,C:white}X1{} Chips for each {C:spectral}{} card',
            [3] = 'held in your {C:attention}consumable{} slots',
            [4] = 'This Joker gains {X:red,C:white}X0.1',
            [5] = '{} Mult when a {C:spectral}Spectral{} card',
            [6] = 'is used',
            [7] = '{C:attention}+4{} consumable slots',
            [8] = '{C:inactive}(Currently{} {X:blue,C:white}X#1#{}{C:inactive} Chips and {}{X:red,C:white}X#2#{}{C:inactive} Mult){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 1,
        y = 3
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 20,
    rarity = 4,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    soul_pos = {
        x = 2,
        y = 3
    },
    in_pool = function(self, args)
          return (
          not args 
          or args.source ~= 'sho' 
           
          )
          and true
      end,

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.xchips, card.ability.extra.xmult}}
    end,

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if context.other_card:is_suit("Spades") or context.other_card:is_suit("Clubs") then
                context.other_card:set_seal("badmodog_deadseal", true)
                return {
                    message = "Card Modified!"
                }
            end
        end
        if context.using_consumeable  then
            if context.consumeable and context.consumeable.ability.set == 'Spectral' then
                return {
                    func = function()
                    card.ability.extra.xmult = (card.ability.extra.xmult) + 0.1
                    return true
                end
                }
            end
        end
        if context.cardarea == G.jokers and context.joker_main  then
                return {
                    x_chips = card.ability.extra.xchips,
                    extra = {
                        Xmult = card.ability.extra.xmult
                        }
                }
        end
        if context.before and context.cardarea == G.jokers  then
                return {
                    func = function()
                    card.ability.extra.xchips = card.ability.extra.consumablesheld + (#(G.consumeables and G.consumeables.cards or {}))
                    return true
                end
                }
        end
    end,

    add_to_deck = function(self, card, from_debuff)
        G.E_MANAGER:add_event(Event({func = function()
            G.consumeables.config.card_limit = G.consumeables.config.card_limit + card.ability.extra.slot_change
            return true
        end }))
    end,

    remove_from_deck = function(self, card, from_debuff)
        G.E_MANAGER:add_event(Event({func = function()
            G.consumeables.config.card_limit = G.consumeables.config.card_limit - card.ability.extra.slot_change
            return true
        end }))
    end
}