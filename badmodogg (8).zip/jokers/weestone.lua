SMODS.Joker{ --Weestone
    key = "weestone",
    config = {
        extra = {
            Xmult = 1.025
        }
    },
    loc_txt = {
        ['name'] = 'Weestone',
        ['text'] = {
            [1] = 'Played {C:hearts}Hearts{} give',
            [2] = '{X:blue,C:white}{X:red,C:white}X1.025{} Mult'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 0,
        y = 8
    },
    display_size = {
        w = 71 * 0.75, 
        h = 95 * 0.75
    },
    cost = 4,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if context.other_card:is_suit("Hearts") then
                return {
                    Xmult = card.ability.extra.Xmult
                }
            end
        end
    end
}