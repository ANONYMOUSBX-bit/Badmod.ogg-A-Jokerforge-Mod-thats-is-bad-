SMODS.Joker{ --Mannequin
    key = "mannequin",
    config = {
        extra = {
        }
    },
    loc_txt = {
        ['name'] = 'Mannequin',
        ['text'] = {
            [1] = '{C:attention}Redeem{} a random {C:attention}voucher{}',
            [2] = 'when {C:attention}Boss Blind{} is {C:attention}defeated{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 0,
        y = 5
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    soul_pos = {
        x = 1,
        y = 5
    },

    calculate = function(self, card, context)
        if context.end_of_round and context.main_eval and G.GAME.blind.boss  then
                local voucher_key = pseudorandom_element(G.P_CENTER_POOLS.Voucher, "c25f52cb").key
    local voucher_card = SMODS.create_card{area = G.play, key = voucher_key}
    voucher_card:start_materialize()
    voucher_card.cost = 0
    G.play:emplace(voucher_card)
    delay(0.8)
    voucher_card:redeem()

    G.E_MANAGER:add_event(Event({
        trigger = 'after',
        delay = 0.5,
        func = function()
            voucher_card:start_dissolve()                
            return true
        end
    }))
                return {
                    message = nil
                }
        end
    end
}