SMODS.Joker{ --Washing Machine
    key = "washingmachine",
    config = {
        extra = {
            chips = 0,
            odds = 4
        }
    },
    loc_txt = {
        ['name'] = 'Washing Machine',
        ['text'] = {
            [1] = 'When a card is scored,',
            [2] = 'add it\'s {C:attention}rank{} to',
            [3] = 'this Joker\'s {C:chips}Chips{}',
            [4] = '{C:inactive}(Currently {C:chips}+#1#{}{C:inactive} Chips){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 7,
        y = 7
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 15,
    rarity = "badmodog_amazing",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        local new_numerator, new_denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'j_badmodog_washingmachine') 
        return {vars = {card.ability.extra.chips, new_numerator, new_denominator}}
    end,

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if context.other_card:get_id() == 2 then
                card.ability.extra.chips = (card.ability.extra.chips) + 2
                return {
                    message = "Upgrade"
                }
            elseif context.other_card:get_id() == 3 then
                card.ability.extra.chips = (card.ability.extra.chips) + 3
                return {
                    message = "Upgrade"
                }
            elseif context.other_card:get_id() == 4 then
                card.ability.extra.chips = (card.ability.extra.chips) + 4
                return {
                    message = "Upgrade"
                }
            elseif context.other_card:get_id() == 10 then
                card.ability.extra.chips = (card.ability.extra.chips) + 10
                return {
                    message = "Upgrade"
                }
            elseif context.other_card:get_id() == 5 then
                card.ability.extra.chips = (card.ability.extra.chips) + 5
                return {
                    message = "Upgrade"
                }
            elseif context.other_card:get_id() == 9 then
                card.ability.extra.chips = (card.ability.extra.chips) + 9
                return {
                    message = "Upgrade"
                }
            elseif context.other_card:get_id() == 6 then
                card.ability.extra.chips = (card.ability.extra.chips) + 6
                return {
                    message = "Upgrade"
                }
            elseif context.other_card:get_id() == 8 then
                card.ability.extra.chips = (card.ability.extra.chips) + 8
                return {
                    message = "Upgrade"
                }
            elseif context.other_card:get_id() == 7 then
                card.ability.extra.chips = (card.ability.extra.chips) + 7
                return {
                    message = "Upgrade"
                }
            elseif context.other_card:get_id() == 11 then
                card.ability.extra.chips = (card.ability.extra.chips) + 10
                return {
                    message = "Upgrade"
                }
            elseif context.other_card:get_id() == 12 then
                card.ability.extra.chips = (card.ability.extra.chips) + 10
                return {
                    message = "Upgrade"
                }
            elseif context.other_card:get_id() == 14 then
                card.ability.extra.chips = (card.ability.extra.chips) + 11
                return {
                    message = "Upgrade"
                }
            elseif context.other_card:get_id() == 13 then
                card.ability.extra.chips = (card.ability.extra.chips) + 10
                return {
                    message = "Upgrade"
                }
            end
        end
        if context.cardarea == G.jokers and context.joker_main  then
                return {
                    chips = card.ability.extra.chips
                }
        end
    end
}