SMODS.Joker{ --Landfill
    key = "landfill",
    config = {
        extra = {
            mult = 5
        }
    },
    loc_txt = {
        ['name'] = 'Landfill',
        ['text'] = {
            [1] = '{C:attention}Fine{} Jokers each',
            [2] = 'give {C:mult}+5{} Mult'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 8,
        y = 4
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.other_joker  then
            if (function()
    return context.other_joker.config.center.rarity == "badmodog_fine"
end)() then
                return {
                    mult = card.ability.extra.mult
                }
            end
        end
    end
}