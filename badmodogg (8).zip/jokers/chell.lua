SMODS.Joker{ --Chell
    key = "chell",
    config = {
        extra = {
            mult = 0
        }
    },
    loc_txt = {
        ['name'] = 'Chell',
        ['text'] = {
            [1] = 'This Joker gains {C:red}+4{} Mult when',
            [2] = 'a {C:attention}#3#{} or {C:attention}#2#{} is scored',
            [3] = '{C:inactive}(Currently {}{C:mult}+#1#{}{C:inactive} Mult, rank{}',
            [4] = '{C:inactive}changes at the end of the',
            [5] = 'round){}{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 2,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.mult, localize((G.GAME.current_round.rank_card or {}).rank or 'Ace', 'ranks'), localize((G.GAME.current_round.rank2_card or {}).rank or 'Ace', 'ranks')}}
    end,

    set_ability = function(self, card, initial)
        G.GAME.current_round.rank_card = { rank = '5', id = 5 }
        G.GAME.current_round.rank2_card = { rank = '9', id = 9 }
    end,

    calculate = function(self, card, context)
        if context.end_of_round and context.game_over == false and context.main_eval  then
                if G.playing_cards then
                        local valid_rank_cards = {}
                        for _, v in ipairs(G.playing_cards) do
                            if not SMODS.has_no_rank(v) then
                                valid_rank_cards[#valid_rank_cards + 1] = v
                            end
                        end
                        if valid_rank_cards[1] then
                            local rank_card = pseudorandom_element(valid_rank_cards, pseudoseed('rank' .. G.GAME.round_resets.ante))
                            G.GAME.current_round.rank_card.rank = rank_card.base.value
                            G.GAME.current_round.rank_card.id = rank_card.base.id
                        end
                    end
                if G.playing_cards then
                        local valid_rank2_cards = {}
                        for _, v in ipairs(G.playing_cards) do
                            if not SMODS.has_no_rank(v) then
                                valid_rank2_cards[#valid_rank2_cards + 1] = v
                            end
                        end
                        if valid_rank2_cards[1] then
                            local rank2_card = pseudorandom_element(valid_rank2_cards, pseudoseed('rank2' .. G.GAME.round_resets.ante))
                            G.GAME.current_round.rank2_card.rank = rank2_card.base.value
                            G.GAME.current_round.rank2_card.id = rank2_card.base.id
                        end
                    end
        end
        if context.individual and context.cardarea == G.play  then
            if (context.other_card:get_id() == G.GAME.current_round.rank_card.id or context.other_card:get_id() == G.GAME.current_round.rank2_card.id) then
                card.ability.extra.mult = (card.ability.extra.mult) + 4
            end
        end
        if context.cardarea == G.jokers and context.joker_main  then
                return {
                    mult = card.ability.extra.mult
                }
        end
    end
}