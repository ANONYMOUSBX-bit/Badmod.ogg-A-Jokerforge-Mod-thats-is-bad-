SMODS.Joker{ --Club
    key = "club",
    config = {
        extra = {
            mult = 7
        }
    },
    loc_txt = {
        ['name'] = 'Club',
        ['text'] = {
            [1] = 'Played {C:attention}7{} of {C:clubs}Clubs{} give',
            [2] = '{C:mult}+7{} Mult'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 3,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 1,
    rarity = "badmodog_fine",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if (context.other_card:get_id() == 7 and context.other_card:is_suit("Clubs")) then
                return {
                    mult = card.ability.extra.mult
                }
            end
        end
    end
}