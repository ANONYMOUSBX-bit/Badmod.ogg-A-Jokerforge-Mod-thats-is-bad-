SMODS.Joker{ --Justice
    key = "justice",
    config = {
        extra = {
        }
    },
    loc_txt = {
        ['name'] = 'Justice',
        ['text'] = {
            [1] = 'Balances {C:chips}Chips{} and {C:mult}Mult{} if',
            [2] = 'played hand is your {C:attention}most played hand{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 6,
        y = 4
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 3,
    blueprint_compat = false,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if (function()
    local current_played = G.GAME.hands[context.scoring_name].played or 0
    for handname, values in pairs(G.GAME.hands) do
        if handname ~= context.scoring_name and values.played > current_played and values.visible then
            return false
        end
    end
    return true
end)() then
                return {
                    balance = true
                }
            end
        end
    end
}