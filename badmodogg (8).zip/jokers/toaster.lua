SMODS.Joker{ --Toaster
    key = "toaster",
    config = {
        extra = {
        }
    },
    loc_txt = {
        ['name'] = 'Toaster',
        ['text'] = {
            [1] = 'Randomize the {C:attention}rank{} and',
            [2] = '{C:attention}suit{} of played cards',
            [3] = 'if played hand is your',
            [4] = '{C:attention}most played hand{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 1,
        y = 7
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if (function()
    local current_played = G.GAME.hands[context.scoring_name].played or 0
    for handname, values in pairs(G.GAME.hands) do
        if handname ~= context.scoring_name and values.played > current_played and values.visible then
            return false
        end
    end
    return true
end)() then
                assert(SMODS.change_base(context.other_card, pseudorandom_element(SMODS.Suits, 'edit_card_suit').key, pseudorandom_element(SMODS.Ranks, 'edit_card_rank').key))
                return {
                    message = "Card Modified!"
                }
            end
        end
    end
}