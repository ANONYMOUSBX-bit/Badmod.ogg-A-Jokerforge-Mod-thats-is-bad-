SMODS.Joker{ --Zombie
    key = "zombie",
    config = {
        extra = {
            Xmult = 3
        }
    },
    loc_txt = {
        ['name'] = 'Zombie',
        ['text'] = {
            [1] = '{X:red,C:white}X3{} Mult{} if played',
            [2] = 'hand is level {C:attention}1'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 2,
        y = 8
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if (function()
    for hand, data in pairs(G.GAME.hands) do
        if hand == context.scoring_name and data.level == 1 then
            return true
        end
    end
    return false
  end)() then
                return {
                    Xmult = card.ability.extra.Xmult
                }
            end
        end
    end
}