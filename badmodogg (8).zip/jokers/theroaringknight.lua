SMODS.Joker{ --The Roaring Knight
    key = "theroaringknight",
    config = {
        extra = {
            pmult = 1
        }
    },
    loc_txt = {
        ['name'] = 'The Roaring Knight',
        ['text'] = {
            [1] = 'This Joker gains {X:enhanced,C:white}^0.05{} Mult',
            [2] = 'when a Joker or Consumable',
            [3] = 'is {C:attention}sold{}',
            [4] = '{C:inactive}(Currently{} {X:enhanced,C:white}^#1#{} {C:inactive}Mult){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 8,
        y = 6
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 75,
    rarity = "badmodog_absurd",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    soul_pos = {
        x = 9,
        y = 6
    },

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.pmult}}
    end,

    calculate = function(self, card, context)
        if context.selling_card  then
                return {
                    func = function()
                    card.ability.extra.pmult = (card.ability.extra.pmult) + 0.05
                    return true
                end,
                    message = "Upgrade"
                }
        end
        if context.cardarea == G.jokers and context.joker_main  then
                return {
                    e_mult = card.ability.extra.pmult
                }
        end
    end
}