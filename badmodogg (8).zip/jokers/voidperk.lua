SMODS.Joker{ --Void Perk
    key = "voidperk",
    config = {
        extra = {
            repetitions = 10,
            repetitions2 = 5
        }
    },
    loc_txt = {
        ['name'] = 'Void Perk',
        ['text'] = {
            [1] = '{C:attention}Retrigger{} the {C:attention}last played',
            [2] = 'card{} {C:attention}5{} times',
            [3] = '{C:attention}Retrigger 10{} times if',
            [4] = 'it is the last hand',
            [5] = 'of the {C:attention}round{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 6,
        y = 7
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 16,
    rarity = "badmodog_amazing",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.repetition and context.cardarea == G.play  then
            if (context.other_card == context.scoring_hand[#context.scoring_hand] and G.GAME.current_round.hands_left == 0) then
                return {
                    repetitions = card.ability.extra.repetitions,
                    message = localize('k_again_ex')
                }
            elseif (context.other_card == context.scoring_hand[#context.scoring_hand] and G.GAME.current_round.hands_left > 0) then
                return {
                    repetitions = card.ability.extra.repetitions2,
                    message = localize('k_again_ex')
                }
            end
        end
    end
}