SMODS.Joker{ --Gold
    key = "gold",
    config = {
        extra = {
            Xmult = 4
        }
    },
    loc_txt = {
        ['name'] = 'Gold',
        ['text'] = {
            [1] = '{X:red,C:white}X4{} Mult if this Joker has',
            [2] = 'a {C:attention}Rental{} sticker'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 4,
        y = 3
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    soul_pos = {
        x = 5,
        y = 3
    },

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if (function()
    return card.ability.rental
end)() then
                return {
                    Xmult = card.ability.extra.Xmult
                }
            end
        end
    end
}