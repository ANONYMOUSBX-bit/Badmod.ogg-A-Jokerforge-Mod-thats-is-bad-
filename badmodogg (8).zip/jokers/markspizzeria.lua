SMODS.Joker{ --Marks Pizzeria
    key = "markspizzeria",
    config = {
        extra = {
            odds = 4,
            dollars = 25
        }
    },
    loc_txt = {
        ['name'] = 'Marks Pizzeria',
        ['text'] = {
            [1] = 'When {C:attention}Blind{} is selected,',
            [2] = '{C:green}1 in 4{} chance to',
            [3] = '--{C:red}KRRRPIOKILR##$%^&@UIU{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 2,
        y = 5
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.setting_blind  then
            if true then
                if SMODS.pseudorandom_probability(card, 'group_0_4c4c0b22', 1, card.ability.extra.odds, 'j_badmodog_markspizzeria', false) then
              SMODS.calculate_effect({dollars = card.ability.extra.dollars}, card)
                        SMODS.calculate_effect({func = function()
                local card_front = G.P_CARDS.S_A
                local new_card = create_playing_card({
                    front = card_front,
                    center = G.P_CENTERS.m_mult
                }, G.discard, true, false, nil, true)
            new_card:set_seal("Blue", true)
            new_card:set_edition("e_foil", true)
                
                G.playing_card = (G.playing_card and G.playing_card + 1) or 1
                new_card.playing_card = G.playing_card
                table.insert(G.playing_cards, new_card)
                
                G.E_MANAGER:add_event(Event({
                    func = function()
                        G.hand:emplace(new_card)
                        new_card:start_materialize()
                        SMODS.calculate_context({ playing_card_added = true, cards = { new_card } })
                        return true
                    end
                }))
            end}, card)
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = " KAAA KAAA KAAA AKAKKAKAKAKAKAK", colour = G.C.GREEN})
          end
            end
        end
    end
}