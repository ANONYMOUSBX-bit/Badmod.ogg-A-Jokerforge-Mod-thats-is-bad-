SMODS.Joker{ --Analog Surprised Face
    key = "analogsurprisedface",
    config = {
        extra = {
            chips = 300,
            mult = 30
        }
    },
    loc_txt = {
        ['name'] = 'Analog Surprised Face',
        ['text'] = {
            [1] = 'Does something ????',
            [2] = '=0',
            [3] = '{C:red}Self Destructs'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 3,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
                return {
                    chips = card.ability.extra.chips,
                    extra = {
                        mult = card.ability.extra.mult,
                            message = "Surprise!",
                        extra = {
                            func = function()
                card:start_dissolve()
                return true
            end,
                            message = "Destroyed!",
                            colour = G.C.RED
                        }
                        }
                }
        end
    end
}