SMODS.Joker{ --Infinity
    key = "infinity",
    config = {
        extra = {
            retriggers = 1
        }
    },
    loc_txt = {
        ['name'] = 'Infinity',
        ['text'] = {
            [1] = 'haha'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 0,
        y = 4
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = "badmodog_idk",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    in_pool = function(self, args)
          return (
          not args 
          or args.source ~= 'sho' and args.source ~= 'buf' and args.source ~= 'jud' 
          or args.source == 'rif' or args.source == 'rta' or args.source == 'sou' or args.source == 'uta' or args.source == 'wra'
          )
          and true
      end,

    calculate = function(self, card, context)
        if context.repetition and context.cardarea == G.play  then
                return {
                    repetitions = card.ability.extra.retriggers,
                    message = localize('k_again_ex')
                }
        end
        if context.individual and context.cardarea == G.play  then
                card.ability.extra.retriggers = (card.ability.extra.retriggers) + 1
        end
    end
}