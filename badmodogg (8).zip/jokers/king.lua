SMODS.Joker{ --King
    key = "king",
    config = {
        extra = {
            xchips = 1,
            odds = 12,
            levels = 1
        }
    },
    loc_txt = {
        ['name'] = 'King',
        ['text'] = {
            [1] = '{C:spades}Spades{}{C:attention} held in hand{} after hand',
            [2] = 'is played have a',
            [3] = '{C:green} 1 in 12{} chance to',
            [4] = '{C:attention}level up{} played hand',
            [5] = 'This Joker gains {X:blue,C:white}X0.2{} Chips',
            [6] = 'when a hand is leveled up',
            [7] = 'this way',
            [8] = '{C:inactive}(Currently{} {X:blue,C:white}X#1#{}{C:inactive} Chips){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 7,
        y = 4
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        local new_numerator, new_denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'j_badmodog_king') 
        return {vars = {card.ability.extra.xchips, new_numerator, new_denominator}}
    end,

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.hand and not context.end_of_round  then
            if context.other_card:is_suit("Spades") then
                if SMODS.pseudorandom_probability(card, 'group_0_d66b43fd', 1, card.ability.extra.odds, 'j_badmodog_king', false) then
              target_hand = (context.scoring_name or "High Card")
                        SMODS.calculate_effect({level_up = card.ability.extra.levels,
      level_up_hand = target_hand}, card)
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = localize('k_level_up_ex'), colour = G.C.RED})
                        SMODS.calculate_effect({func = function()
                    card.ability.extra.xchips = (card.ability.extra.xchips) + 0.2
                    return true
                end}, card)
          end
            end
        end
        if context.cardarea == G.jokers and context.joker_main  then
                return {
                    x_chips = card.ability.extra.xchips
                }
        end
    end
}