SMODS.Joker{ --Analog Smiling Face
    key = "analogsmilingface",
    config = {
        extra = {
            chips = 0
        }
    },
    loc_txt = {
        ['name'] = 'Analog Smiling Face',
        ['text'] = {
            [1] = 'This Joker gains {C:chips}+1{} Chip',
            [2] = 'when a {C:attention}face{} card is',
            [3] = 'scored =)',
            [4] = '{C:inactive}(Currently{}{C:chips} +#1#{}{C:inactive} Chips)'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 2,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 0,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.chips}}
    end,

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if context.other_card:is_face() then
                card.ability.extra.chips = (card.ability.extra.chips) + 1
                return {
                    message = "Upgrade"
                }
            end
        end
        if context.cardarea == G.jokers and context.joker_main  then
                return {
                    chips = card.ability.extra.chips
                }
        end
    end
}