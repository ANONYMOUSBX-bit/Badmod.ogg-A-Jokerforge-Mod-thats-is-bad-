SMODS.Joker{ --GLaDOS
    key = "glados",
    config = {
        extra = {
            xchips = 1,
            eternal = 0,
            ignore = 0
        }
    },
    loc_txt = {
        ['name'] = 'GLaDOS',
        ['text'] = {
            [1] = 'This Joker creates an {C:attention}Eternal',
            [2] = 'Neurotoxin {}and gains {X:blue,C:white}X0.75{} Chips',
            [3] = 'when Blind is {C:attention}selected{}',
            [4] = '{C:inactive}(Currently{} {X:blue,C:white}X#1#{}{C:inactive} Chips){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 3,
        y = 3
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.xchips}}
    end,

    calculate = function(self, card, context)
        if context.setting_blind  then
                return {
                    func = function()
            local created_joker = true
            G.E_MANAGER:add_event(Event({
                func = function()
                    local joker_card = SMODS.add_card({ set = 'Joker', key = 'j_badmodog_neurotoxin' })
                    if joker_card then
                        
                        joker_card:add_sticker('eternal', true)
                    end
                    
                    return true
                end
            }))
            
            if created_joker then
                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "NEUROTOXINS", colour = G.C.BLUE})
            end
            return true
        end,
                    extra = {
                        func = function()
                    card.ability.extra.xchips = (card.ability.extra.xchips) + 0.75
                    return true
                end,
                        colour = G.C.GREEN
                        }
                }
        end
        if context.cardarea == G.jokers and context.joker_main  then
                return {
                    x_chips = card.ability.extra.xchips
                }
        end
    end
}