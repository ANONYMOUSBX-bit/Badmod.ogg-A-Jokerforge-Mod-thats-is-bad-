SMODS.Joker{ --Fandom
    key = "fandom",
    config = {
        extra = {
            mult = 0
        }
    },
    loc_txt = {
        ['name'] = 'Fandom',
        ['text'] = {
            [1] = 'This Joker gains {C:red}+2{} Mult',
            [2] = 'when a {C:attention}Pair{} is played',
            [3] = '{C:inactive}(Currently {}{C:mult}+#1#{} {C:inactive}Mult){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 5,
        y = 2
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 7,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.mult}}
    end,

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if context.scoring_name == "Pair" then
                card.ability.extra.mult = (card.ability.extra.mult) + 2
            else
                return {
                    mult = card.ability.extra.mult
                }
            end
        end
    end
}