SMODS.Joker{ --Pipe
    key = "pipe",
    config = {
        extra = {
            odds = 2,
            ignore = 0
        }
    },
    loc_txt = {
        ['name'] = 'Pipe',
        ['text'] = {
            [1] = '{C:green}1 in 2{} chance to create',
            [2] = 'a {C:attention}Smoke Puff{} when',
            [3] = 'Blind is defeated'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 9,
        y = 5
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.end_of_round and context.game_over == false and context.main_eval  then
            if true then
                if SMODS.pseudorandom_probability(card, 'group_0_61121379', 1, card.ability.extra.odds, 'j_badmodog_pipe', false) then
              SMODS.calculate_effect({func = function()
            local created_joker = true
            G.E_MANAGER:add_event(Event({
                func = function()
                    local joker_card = SMODS.add_card({ set = 'Joker', key = 'j_badmodog_smokepuff' })
                    if joker_card then
                        
                        
                    end
                    
                    return true
                end
            }))
            
            if created_joker then
                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "pipe.", colour = G.C.BLUE})
            end
            return true
        end}, card)
          end
            end
        end
    end
}