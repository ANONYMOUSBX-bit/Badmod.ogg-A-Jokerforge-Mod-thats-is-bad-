SMODS.Joker{ --Google Chrome
    key = "googlechrome",
    config = {
        extra = {
            dollars = 1,
            chips = 10,
            mult = 2,
            odds = 6,
            Xmult = 1.25
        }
    },
    loc_txt = {
        ['name'] = 'Google Chrome',
        ['text'] = {
            [1] = '{C:mult}+2{} Mult and {C:chips}+10{} Chips',
            [2] = '{C:green}1 in 6{} chance for {X:red,C:white}X1.25{} Mult',
            [3] = 'Earn {C:money}$1{} if played hand',
            [4] = 'is a {C:attention}Four of a Kind'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 6,
        y = 3
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 2,
    rarity = "badmodog_fine",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if next(context.poker_hands["Four of a Kind"]) then
                return {
                    dollars = card.ability.extra.dollars
                }
            elseif true then
                return {
                    chips = card.ability.extra.chips,
                    extra = {
                        mult = card.ability.extra.mult
                        }
                ,
                    func = function()
                        if SMODS.pseudorandom_probability(card, 'group_0_5fd179ff', 1, card.ability.extra.odds, 'j_badmodog_googlechrome', false) then
              SMODS.calculate_effect({Xmult = card.ability.extra.Xmult}, card)
          end
                        return true
                    end
                }
            end
        end
    end
}