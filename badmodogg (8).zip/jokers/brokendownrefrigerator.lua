SMODS.Joker{ --Broken Down Refrigerator
    key = "brokendownrefrigerator",
    config = {
        extra = {
            Xmult = 2.5
        }
    },
    loc_txt = {
        ['name'] = 'Broken Down Refrigerator',
        ['text'] = {
            [1] = '{C:attention}Perishable{} Jokers each give {X:red,C:white}X2.5{} Mult',
            [2] = '{C:inactive}(Always spawns Perishable)'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 8,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    set_ability = function(self, card, initial)
        card:add_sticker('perishable', true)
    end,

    calculate = function(self, card, context)
        if context.other_joker  then
            if (function()
    return context.other_joker.ability.perishable
end)() then
                return {
                    Xmult = card.ability.extra.Xmult
                }
            end
        end
    end
}