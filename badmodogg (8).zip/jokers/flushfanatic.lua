SMODS.Joker{ --Flush Fanatic
    key = "flushfanatic",
    config = {
        extra = {
            Chips = 0
        }
    },
    loc_txt = {
        ['name'] = 'Flush Fanatic',
        ['text'] = {
            [1] = 'This Joker gains {C:chips}+17{} Chips if',
            [2] = 'played hand is a {C:attention}Flush{}',
            [3] = '{C:inactive}(Currently {C:chips}+#1#{}{C:inactive} Chips){}{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 6,
        y = 2
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.Chips}}
    end,

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
                return {
                    chips = card.ability.extra.Chips
                }
        end
        if context.before and context.cardarea == G.jokers  then
            if context.scoring_name == "Flush" then
                return {
                    func = function()
                    card.ability.extra.Chips = (card.ability.extra.Chips) + 17
                    return true
                end,
                    message = "FLUSH"
                }
            end
        end
    end
}