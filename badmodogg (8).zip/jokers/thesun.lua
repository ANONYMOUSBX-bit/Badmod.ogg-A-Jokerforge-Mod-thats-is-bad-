SMODS.Joker{ --The Sun
    key = "thesun",
    config = {
        extra = {
            odds = 7
        }
    },
    loc_txt = {
        ['name'] = 'The Sun',
        ['text'] = {
            [1] = 'Played cards with the {C:hearts}Heart{} suit',
            [2] = 'have a {C:green}1 in 7{} chance to become',
            [3] = '{C:attention}Solar{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 0,
        y = 7
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 18,
    rarity = "badmodog_amazing",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if context.other_card:is_suit("Hearts") then
                if SMODS.pseudorandom_probability(card, 'group_0_7547c7fe', 1, card.ability.extra.odds, 'j_badmodog_thesun', false) then
              context.other_card:set_ability(G.P_CENTERS.m_badmodog_solar)
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Upgrade!", colour = G.C.BLUE})
          end
            end
        end
    end
}