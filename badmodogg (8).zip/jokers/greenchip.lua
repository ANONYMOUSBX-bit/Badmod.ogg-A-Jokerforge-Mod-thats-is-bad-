SMODS.Joker{ --Green Chip
    key = "greenchip",
    config = {
        extra = {
            chips = 25
        }
    },
    loc_txt = {
        ['name'] = 'Green Chip',
        ['text'] = {
            [1] = '{C:chips}+25{} Chips'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 7,
        y = 3
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 1,
    rarity = "badmodog_fine",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
                return {
                    chips = card.ability.extra.chips
                }
        end
    end
}