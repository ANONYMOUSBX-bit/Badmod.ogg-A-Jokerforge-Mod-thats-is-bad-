SMODS.Joker{ --Emerald
    key = "emerald",
    config = {
        extra = {
            odds = 4
        }
    },
    loc_txt = {
        ['name'] = 'Emerald',
        ['text'] = {
            [1] = '{C:green}1 in 4{} chance to create',
            [2] = 'a {C:tarot}Tarot{} card when',
            [3] = 'a Joker or consumable',
            [4] = 'is {C:attention}sold{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 1,
        y = 2
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = false,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    soul_pos = {
        x = 2,
        y = 2
    },

    calculate = function(self, card, context)
        if context.selling_card  then
            if true then
                if SMODS.pseudorandom_probability(card, 'group_0_0294b2b8', 1, card.ability.extra.odds, 'j_badmodog_emerald', false) then
              SMODS.calculate_effect({func = function()local created_consumable = false
                if #G.consumeables.cards + G.GAME.consumeable_buffer < G.consumeables.config.card_limit then
                    created_consumable = true
                    G.GAME.consumeable_buffer = G.GAME.consumeable_buffer + 1
                    G.E_MANAGER:add_event(Event({
                        func = function()
                            SMODS.add_card{set = 'Tarot', key = nil, key_append = 'joker_forge_tarot'}
                            G.GAME.consumeable_buffer = 0
                            return true
                        end
                    }))
                end
                    if created_consumable then
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Hrmmm", colour = G.C.PURPLE})
                    end
                    return true
                end}, card)
          end
            end
        end
    end
}