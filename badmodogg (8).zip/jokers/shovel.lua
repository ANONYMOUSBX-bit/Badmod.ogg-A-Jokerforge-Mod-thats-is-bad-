SMODS.Joker{ --Shovel
    key = "shovel",
    config = {
        extra = {
            xchips = 1.075
        }
    },
    loc_txt = {
        ['name'] = 'Shovel',
        ['text'] = {
            [1] = 'Played {C:spades}Spades{} give',
            [2] = '{X:blue,C:white}X1.075{} Chips'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 3,
        y = 6
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if context.other_card:is_suit("Spades") then
                return {
                    x_chips = card.ability.extra.xchips
                }
            end
        end
    end
}