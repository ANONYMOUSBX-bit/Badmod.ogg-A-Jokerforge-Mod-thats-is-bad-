SMODS.Joker{ --Garfield The Cat
    key = "garfieldthecat",
    config = {
        extra = {
            xchips = 1,
            xmult = 1
        }
    },
    loc_txt = {
        ['name'] = 'Garfield The Cat',
        ['text'] = {
            [1] = 'This Joker gains {X:red,C:white}X0.1{} Mult when',
            [2] = 'a Joker or consumable is {C:attention}sold{}',
            [3] = 'This Joker gains {X:blue,C:white}X0.1{} Chips',
            [4] = 'when a consumable',
            [5] = 'is {C:attention}used{}',
            [6] = '{C:inactive}(Currently {X:red,C:white}X#2#{}{C:inactive} Mult and{} {X:blue,C:white}X#1#{}{C:inactive} Chips)'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 9,
        y = 2
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 20,
    rarity = 4,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    soul_pos = {
        x = 0,
        y = 3
    },
    in_pool = function(self, args)
          return (
          not args 
          or args.source ~= 'sho' 
           
          )
          and true
      end,

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.xchips, card.ability.extra.xmult}}
    end,

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
                return {
                    x_chips = card.ability.extra.xchips,
                    extra = {
                        Xmult = card.ability.extra.xmult
                        }
                }
        end
        if context.using_consumeable  then
                return {
                    func = function()
                    card.ability.extra.xchips = (card.ability.extra.xchips) + 0.1
                    return true
                end,
                    message = "Upgrade"
                }
        end
        if context.selling_card  then
                return {
                    func = function()
                    card.ability.extra.xmult = (card.ability.extra.xmult) + 0.1
                    return true
                end,
                    message = "Upgrade"
                }
        end
    end
}