SMODS.Joker{ --Normal Face
    key = "normalface",
    config = {
        extra = {
            dollars = 20
        }
    },
    loc_txt = {
        ['name'] = 'Normal Face',
        ['text'] = {
            [1] = 'Earn {C:money}$20{} when {C:attention}Small Blind{}',
            [2] = 'is defeated'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 6,
        y = 5
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 7,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.end_of_round and context.game_over == false and context.main_eval  then
            if G.GAME.blind:get_type() == 'Small' then
                return {
                    dollars = card.ability.extra.dollars
                }
            end
        end
    end
}