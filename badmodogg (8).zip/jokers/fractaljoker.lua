SMODS.Joker{ --Fractal Joker
    key = "fractaljoker",
    config = {
        extra = {
            Xmult = 1.75
        }
    },
    loc_txt = {
        ['name'] = 'Fractal Joker',
        ['text'] = {
            [1] = '{C:attention}Eternal{} Jokers each give {X:red,C:white}X1.75{} Mult',
            [2] = '{C:inactive}(Always spawns Eternal)'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 8,
        y = 2
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    set_ability = function(self, card, initial)
        card:set_eternal(true)
    end,

    calculate = function(self, card, context)
        if context.other_joker  then
            if (function()
    return context.other_joker.ability.eternal
end)() then
                return {
                    Xmult = card.ability.extra.Xmult
                }
            end
        end
    end
}