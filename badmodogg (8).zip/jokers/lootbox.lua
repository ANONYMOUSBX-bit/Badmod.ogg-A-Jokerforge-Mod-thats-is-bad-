SMODS.Joker{ --Loot Box
    key = "lootbox",
    config = {
        extra = {
            alreadycreated = 0,
            odds = 2,
            odds2 = 5,
            odds3 = 15,
            odds4 = 35,
            odds5 = 20,
            odds6 = 185,
            respect = 0,
            amazing = 0,
            absurd = 0
        }
    },
    loc_txt = {
        ['name'] = 'Loot Box',
        ['text'] = {
            [1] = 'When sold:',
            [2] = '{C:green}1 in 2{} chance to create',
            [3] = 'a {C:attention}Common{} Joker',
            [4] = '{C:green}1 in 5{} chance to create',
            [5] = 'a {C:attention}Uncommon{} Joker',
            [6] = '{C:green} 1  in 12{} chance to create',
            [7] = 'a {C:attention}Rare{} Joker',
            [8] = '{C:green}1 in 25{} chance to create',
            [9] = 'an {C:attention}Amazing{} Joker',
            [10] = '{C:green}1 in 35{} chance to create',
            [11] = 'a {C:legendary}Legendary{} Joker',
            [12] = '{C:green}1 in 185{} chance to create',
            [13] = 'an {C:enhanced}Absurd{} Joker'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 9,
        y = 4
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.selling_self  then
            if card.ability.extra.alreadycreated ~= 1 then
                if SMODS.pseudorandom_probability(card, 'group_0_367ef288', 1, card.ability.extra.odds, 'j_badmodog_lootbox', false) then
              SMODS.calculate_effect({func = function()
            local created_joker = false
    if #G.jokers.cards + G.GAME.joker_buffer < G.jokers.config.card_limit then
        created_joker = true
        G.GAME.joker_buffer = G.GAME.joker_buffer + 1
            G.E_MANAGER:add_event(Event({
                func = function()
                    local joker_card = SMODS.add_card({ set = 'Joker', rarity = 'Common' })
                    if joker_card then
                        
                        
                    end
                    G.GAME.joker_buffer = 0
                    return true
                end
            }))
            end
            if created_joker then
                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = localize('k_plus_joker'), colour = G.C.BLUE})
            end
            return true
        end}, card)
                        SMODS.calculate_effect({func = function()
                    card.ability.extra.alreadycreated = 1
                    return true
                end}, card)
          end
                if SMODS.pseudorandom_probability(card, 'group_1_4b1e2cd1', 1, card.ability.extra.odds2, 'j_badmodog_lootbox', false) then
              SMODS.calculate_effect({func = function()
            local created_joker = false
    if #G.jokers.cards + G.GAME.joker_buffer < G.jokers.config.card_limit then
        created_joker = true
        G.GAME.joker_buffer = G.GAME.joker_buffer + 1
            G.E_MANAGER:add_event(Event({
                func = function()
                    local joker_card = SMODS.add_card({ set = 'Joker', rarity = 'Uncommon' })
                    if joker_card then
                        
                        
                    end
                    G.GAME.joker_buffer = 0
                    return true
                end
            }))
            end
            if created_joker then
                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = localize('k_plus_joker'), colour = G.C.BLUE})
            end
            return true
        end}, card)
                        SMODS.calculate_effect({func = function()
                    card.ability.extra.alreadycreated = 1
                    return true
                end}, card)
          end
                if SMODS.pseudorandom_probability(card, 'group_2_f49e359e', 1, card.ability.extra.odds3, 'j_badmodog_lootbox', false) then
              SMODS.calculate_effect({func = function()
            local created_joker = false
    if #G.jokers.cards + G.GAME.joker_buffer < G.jokers.config.card_limit then
        created_joker = true
        G.GAME.joker_buffer = G.GAME.joker_buffer + 1
            G.E_MANAGER:add_event(Event({
                func = function()
                    local joker_card = SMODS.add_card({ set = 'Joker', rarity = 'Rare' })
                    if joker_card then
                        
                        
                    end
                    G.GAME.joker_buffer = 0
                    return true
                end
            }))
            end
            if created_joker then
                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = localize('k_plus_joker'), colour = G.C.BLUE})
            end
            return true
        end}, card)
                        SMODS.calculate_effect({func = function()
                    card.ability.extra.alreadycreated = 1
                    return true
                end}, card)
          end
                if SMODS.pseudorandom_probability(card, 'group_3_10327a71', 1, card.ability.extra.odds4, 'j_badmodog_lootbox', false) then
              SMODS.calculate_effect({func = function()
            local created_joker = false
    if #G.jokers.cards + G.GAME.joker_buffer < G.jokers.config.card_limit then
        created_joker = true
        G.GAME.joker_buffer = G.GAME.joker_buffer + 1
            G.E_MANAGER:add_event(Event({
                func = function()
                    local joker_card = SMODS.add_card({ set = 'Joker', rarity = 'Legendary' })
                    if joker_card then
                        
                        
                    end
                    G.GAME.joker_buffer = 0
                    return true
                end
            }))
            end
            if created_joker then
                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = localize('k_plus_joker'), colour = G.C.BLUE})
            end
            return true
        end}, card)
                        SMODS.calculate_effect({func = function()
                    card.ability.extra.alreadycreated = 1
                    return true
                end}, card)
          end
                if SMODS.pseudorandom_probability(card, 'group_4_1dc7ac16', 1, card.ability.extra.odds5, 'j_badmodog_lootbox', false) then
              SMODS.calculate_effect({func = function()
                    card.ability.extra.alreadycreated = 1
                    return true
                end}, card)
                        SMODS.calculate_effect({func = function()
            local created_joker = false
    if #G.jokers.cards + G.GAME.joker_buffer < G.jokers.config.card_limit then
        created_joker = true
        G.GAME.joker_buffer = G.GAME.joker_buffer + 1
            G.E_MANAGER:add_event(Event({
                func = function()
                    local joker_card = SMODS.add_card({ set = 'Joker', rarity = 'badmodog_amazing' })
                    if joker_card then
                        
                        
                    end
                    G.GAME.joker_buffer = 0
                    return true
                end
            }))
            end
            if created_joker then
                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = localize('k_plus_joker'), colour = G.C.BLUE})
            end
            return true
        end}, card)
          end
                if SMODS.pseudorandom_probability(card, 'group_5_c099dd96', 1, card.ability.extra.odds6, 'j_badmodog_lootbox', false) then
              SMODS.calculate_effect({func = function()
            local created_joker = false
    if #G.jokers.cards + G.GAME.joker_buffer < G.jokers.config.card_limit then
        created_joker = true
        G.GAME.joker_buffer = G.GAME.joker_buffer + 1
            G.E_MANAGER:add_event(Event({
                func = function()
                    local joker_card = SMODS.add_card({ set = 'Joker', rarity = 'badmodog_absurd' })
                    if joker_card then
                        
                        
                    end
                    G.GAME.joker_buffer = 0
                    return true
                end
            }))
            end
            if created_joker then
                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = localize('k_plus_joker'), colour = G.C.BLUE})
            end
            return true
        end}, card)
                        SMODS.calculate_effect({func = function()
                    card.ability.extra.alreadycreated = 1
                    return true
                end}, card)
          end
            end
        end
    end
}