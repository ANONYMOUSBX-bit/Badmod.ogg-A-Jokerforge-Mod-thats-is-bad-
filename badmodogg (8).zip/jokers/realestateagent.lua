SMODS.Joker{ --Real Estate Agent
    key = "realestateagent",
    config = {
        extra = {
            xmult = 1
        }
    },
    loc_txt = {
        ['name'] = 'Real Estate Agent',
        ['text'] = {
            [1] = 'This Joker gains {X:red,C:white}X0.15{} Mult',
            [2] = 'if played hand is a {C:attention}Full House{}',
            [3] = '{C:inactive}(Currently{} {X:red,C:white}X#1#{} {C:inactive}Mult){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 0,
        y = 6
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 7,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.xmult}}
    end,

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if context.scoring_name == "Full House" then
                card.ability.extra.xmult = (card.ability.extra.xmult) + 0.15
            else
                return {
                    Xmult = card.ability.extra.xmult
                }
            end
        end
    end
}