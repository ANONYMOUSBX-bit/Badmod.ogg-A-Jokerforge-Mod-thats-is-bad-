SMODS.Joker{ --Uranium
    key = "uranium",
    config = {
        extra = {
            odds = 4
        }
    },
    loc_txt = {
        ['name'] = 'Uranium',
        ['text'] = {
            [1] = 'Played {C:attention}#1#s{} have a {C:green}1 in 2{} chance',
            [2] = 'to gain a random {C:attention}seal',
            [3] = '{}{C:inactive}(Suit changes at the end of the',
            [4] = '{C:inactive}round){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 5,
        y = 7
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        local new_numerator, new_denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'j_badmodog_uranium') 
        return {vars = {localize((G.GAME.current_round.suit_card or {}).suit or 'Spades', 'suits_singular'), new_numerator, new_denominator}}
    end,

    set_ability = function(self, card, initial)
        G.GAME.current_round.suit_card = { suit = 'Diamonds' }
    end,

    calculate = function(self, card, context)
        if context.end_of_round and context.game_over == false and context.main_eval  then
                if G.playing_cards then
                    local valid_suit_cards = {}
                    for _, v in ipairs(G.playing_cards) do
                        if not SMODS.has_no_suit(v) then
                            valid_suit_cards[#valid_suit_cards + 1] = v
                        end
                    end
                    if valid_suit_cards[1] then
                        local suit_card = pseudorandom_element(valid_suit_cards, pseudoseed('suit' .. G.GAME.round_resets.ante))
                        G.GAME.current_round.suit_card.suit = suit_card.base.suit
                    end
                end
        end
        if context.individual and context.cardarea == G.play  then
            if context.other_card:is_suit(G.GAME.current_round.suit_card.suit) then
                if SMODS.pseudorandom_probability(card, 'group_0_fb57471b', 1, card.ability.extra.odds, 'j_badmodog_uranium', false) then
              local random_seal = SMODS.poll_seal({mod = 10, guaranteed = true})
                if random_seal then
                    context.other_card:set_seal(random_seal, true)
                end
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Card Modified!", colour = G.C.BLUE})
          end
            end
        end
    end
}