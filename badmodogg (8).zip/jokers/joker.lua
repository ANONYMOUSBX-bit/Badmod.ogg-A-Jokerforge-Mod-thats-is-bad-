SMODS.Joker{ --Joker?
    key = "joker",
    config = {
        extra = {
        }
    },
    loc_txt = {
        ['name'] = 'Joker?',
        ['text'] = {
            [1] = '{C:attention}Copies{} the ability',
            [2] = 'of the {C:attention}sixth{} Joker'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 5,
        y = 4
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        
        local target_joker = nil
        
        target_joker = G.jokers.cards[6]
        if target_joker == card then
            target_joker = nil
        end
        
        local ret = SMODS.blueprint_effect(card, target_joker, context)
        if ret then
            SMODS.calculate_effect(ret, card)
        end
    end
}