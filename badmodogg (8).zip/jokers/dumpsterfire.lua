SMODS.Joker{ --Dumpster Fire
    key = "dumpsterfire",
    config = {
        extra = {
            chips = 45
        }
    },
    loc_txt = {
        ['name'] = 'Dumpster Fire',
        ['text'] = {
            [1] = '{C:common}Common{} Joker each give',
            [2] = '{C:chips}+45{} Chips'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 9,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.other_joker  then
            if (function()
    return context.other_joker.config.center.rarity == 1
end)() then
                return {
                    chips = card.ability.extra.chips
                }
            end
        end
    end
}