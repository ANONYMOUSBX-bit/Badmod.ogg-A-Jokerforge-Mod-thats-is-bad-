SMODS.Joker{ --Trash Can
    key = "trashcan",
    config = {
        extra = {
            dollars = 2
        }
    },
    loc_txt = {
        ['name'] = 'Trash Can',
        ['text'] = {
            [1] = 'Earn {C:money}$2{} when a {C:red}Discard{}',
            [2] = 'is used'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 2,
        y = 7
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.pre_discard  then
                return {
                    dollars = card.ability.extra.dollars
                }
        end
    end
}