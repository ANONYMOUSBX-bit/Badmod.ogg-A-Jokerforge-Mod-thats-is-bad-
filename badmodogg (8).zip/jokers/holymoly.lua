SMODS.Joker{ --holy moly
    key = "holymoly",
    config = {
        extra = {
            Xmult = 3,
            badmodog_holymoly_sound = 0
        }
    },
    loc_txt = {
        ['name'] = 'holy moly',
        ['text'] = {
            [1] = '{X:red,C:white}X3{} Mult'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 8,
        y = 3
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 7,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
                play_sound("badmodog_holymoly_sound")
                return {
                    Xmult = card.ability.extra.Xmult
                }
        end
    end
}