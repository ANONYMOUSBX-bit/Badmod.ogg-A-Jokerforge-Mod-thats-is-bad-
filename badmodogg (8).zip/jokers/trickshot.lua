SMODS.Joker{ --Trickshot
    key = "trickshot",
    config = {
        extra = {
            Xmult = 2.5,
            Xmult2 = 0.5
        }
    },
    loc_txt = {
        ['name'] = 'Trickshot',
        ['text'] = {
            [1] = 'Played {C:attention}#1#s{} and {C:attention}#2#s{} give {X:red,C:white}X2.5{} Mult',
            [2] = 'All other cards give {X:red,C:white}X0.5{} Mult',
            [3] = 'Rank changes {C:attention}at the end of the',
            [4] = 'round'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 3,
        y = 7
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {localize((G.GAME.current_round.rank1_card or {}).rank or 'Ace', 'ranks'), localize((G.GAME.current_round.rank2_card or {}).rank or 'Ace', 'ranks')}}
    end,

    set_ability = function(self, card, initial)
        G.GAME.current_round.rank1_card = { rank = '4', id = 4 }
        G.GAME.current_round.rank2_card = { rank = '3', id = 3 }
    end,

    calculate = function(self, card, context)
        if context.end_of_round and context.game_over == false and context.main_eval  then
                if G.playing_cards then
                        local valid_rank1_cards = {}
                        for _, v in ipairs(G.playing_cards) do
                            if not SMODS.has_no_rank(v) then
                                valid_rank1_cards[#valid_rank1_cards + 1] = v
                            end
                        end
                        if valid_rank1_cards[1] then
                            local rank1_card = pseudorandom_element(valid_rank1_cards, pseudoseed('rank1' .. G.GAME.round_resets.ante))
                            G.GAME.current_round.rank1_card.rank = rank1_card.base.value
                            G.GAME.current_round.rank1_card.id = rank1_card.base.id
                        end
                    end
                if G.playing_cards then
                        local valid_rank2_cards = {}
                        for _, v in ipairs(G.playing_cards) do
                            if not SMODS.has_no_rank(v) then
                                valid_rank2_cards[#valid_rank2_cards + 1] = v
                            end
                        end
                        if valid_rank2_cards[1] then
                            local rank2_card = pseudorandom_element(valid_rank2_cards, pseudoseed('rank2' .. G.GAME.round_resets.ante))
                            G.GAME.current_round.rank2_card.rank = rank2_card.base.value
                            G.GAME.current_round.rank2_card.id = rank2_card.base.id
                        end
                    end
        end
        if context.individual and context.cardarea == G.play  then
            if (context.other_card:get_id() == G.GAME.current_round.rank1_card.id or context.other_card:get_id() == G.GAME.current_round.rank2_card.id) then
                return {
                    Xmult = card.ability.extra.Xmult
                }
            elseif (not (context.other_card:get_id() == G.GAME.current_round.rank2_card.id) or not (context.other_card:get_id() == G.GAME.current_round.rank1_card.id)) then
                return {
                    Xmult = card.ability.extra.Xmult2
                }
            end
        end
    end
}