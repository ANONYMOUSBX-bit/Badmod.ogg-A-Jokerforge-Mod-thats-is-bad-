SMODS.Joker{ --Jack of all Trades
    key = "jackofalltrades",
    config = {
        extra = {
            Xmult = 1.25,
            xchips = 1.5,
            dollars = 1
        }
    },
    loc_txt = {
        ['name'] = 'Jack of all Trades',
        ['text'] = {
            [1] = 'Played cards give',
            [2] = '{C:money}$1{}, {X:red,C:white}X1.25{} Mult, and {X:blue,C:white}X1.5{}',
            [3] = 'Chips'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 2,
        y = 4
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 16,
    rarity = "badmodog_amazing",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
                return {
                    Xmult = card.ability.extra.Xmult,
                    extra = {
                        x_chips = card.ability.extra.xchips,
                        colour = G.C.DARK_EDITION,
                        extra = {
                            dollars = card.ability.extra.dollars,
                            colour = G.C.MONEY
                        }
                        }
                }
        end
    end
}