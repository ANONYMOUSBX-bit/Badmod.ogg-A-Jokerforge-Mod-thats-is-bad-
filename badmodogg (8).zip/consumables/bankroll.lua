SMODS.Consumable {
    key = 'bankroll',
    set = 'gambling',
    pos = { x = 0, y = 0 },
    config = { extra = {
        odds = 4,
        dollars_value = 50
    } },
    loc_txt = {
        name = ' Bankroll',
        text = {
        [1] = '{C:green}1 in 4{} chance to gain',
        [2] = '{C:money}$50{}'
    }
    },
    cost = 3,
    unlocked = true,
    discovered = true,
    hidden = false,
    can_repeat_soul = false,
    atlas = 'CustomConsumables',
    use = function(self, card, area, copier)
        local used_card = copier or card
            if SMODS.pseudorandom_probability(card, 'group_0_158b59a8', 1, card.ability.extra.odds, 'c_badmodog_bankroll', false) then
                
                G.E_MANAGER:add_event(Event({
                trigger = 'after',
                delay = 0.4,
                func = function()
                    card_eval_status_text(used_card, 'extra', nil, nil, nil, {message = "+"..tostring(50).." $", colour = G.C.MONEY})
                    ease_dollars(50, true)
                    return true
                end
            }))
            delay(0.6)
            end
    end,
    can_use = function(self, card)
        return true
    end
}