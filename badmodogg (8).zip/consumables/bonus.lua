SMODS.Consumable {
    key = 'bonus',
    set = 'gambling',
    pos = { x = 5, y = 0 },
    config = { extra = {
        odds = 4,
        consumable_count = 2
    } },
    loc_txt = {
        name = 'Bonus',
        text = {
        [1] = '{C:green}3 in 4{} chance to',
        [2] = 'create {C:attention}2{} {C:red}Gambling{} cards'
    }
    },
    cost = 3,
    unlocked = true,
    discovered = true,
    hidden = false,
    can_repeat_soul = false,
    atlas = 'CustomConsumables',
    use = function(self, card, area, copier)
        local used_card = copier or card
            if SMODS.pseudorandom_probability(card, 'group_0_5aac1cc3', 3, card.ability.extra.odds, 'c_badmodog_bonus', false) then
                
                for i = 1, math.min(2, G.consumeables.config.card_limit - #G.consumeables.cards) do
                G.E_MANAGER:add_event(Event({
                    trigger = 'after',
                    delay = 0.4,
                    func = function()
                        if G.consumeables.config.card_limit > #G.consumeables.cards then
                            play_sound('timpani')
                            SMODS.add_card({ set = 'gambling' })
                            used_card:juice_up(0.3, 0.5)
                        end
                        return true
                    end
                }))
            end
            delay(0.6)
            end
    end,
    can_use = function(self, card)
        return true
    end
}