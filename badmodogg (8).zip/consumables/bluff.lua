SMODS.Consumable {
    key = 'bluff',
    set = 'gambling',
    pos = { x = 4, y = 0 },
    config = { extra = {
        odds = 6,
        add_cards_count = 8
    } },
    loc_txt = {
        name = 'Bluff',
        text = {
        [1] = '{C:green}1 in 6{} chance to add',
        [2] = '{C:attention}8{} {C:attention} {C:red}Red Seal{} {C:enhanced} Polychrome',
        [3] = 'Steel{} {C:attention}King of{} {C:hearts}Hearts{}',
        [4] = 'to your deck'
    }
    },
    cost = 3,
    unlocked = true,
    discovered = true,
    hidden = false,
    can_repeat_soul = false,
    atlas = 'CustomConsumables',
    use = function(self, card, area, copier)
        local used_card = copier or card
            if SMODS.pseudorandom_probability(card, 'group_0_0566e140', 1, card.ability.extra.odds, 'c_badmodog_bluff', false) then
                
                G.E_MANAGER:add_event(Event({
                trigger = 'after',
                delay = 0.7,
                func = function()
                    local cards = {}
                    for i = 1, 8 do
                        local _rank = 'King'
                        local _suit = 'Hearts'
                        local enhancement = G.P_CENTERS['m_steel']
                        local new_card_params = { set = "Base" }
                        if _rank then new_card_params.rank = _rank end
                        if _suit then new_card_params.suit = _suit end
                        if enhancement then new_card_params.enhancement = enhancement.key end
                        cards[i] = SMODS.add_card(new_card_params)
                        if cards[i] then
                            cards[i]:set_seal('Red', nil, true)
                        end
                        if cards[i] then
                            cards[i]:set_edition({ polychrome = true }, true)
                        end
                    end
                    SMODS.calculate_context({ playing_card_added = true, cards = cards })
                    return true
                end
            }))
            delay(0.3)
            end
    end,
    can_use = function(self, card)
        return true
    end
}