SMODS.Consumable {
    key = 'roll',
    set = 'gambling',
    pos = { x = 0, y = 1 },
    config = { extra = {
        odds = 4,
        joker_slots_value = 1
    } },
    loc_txt = {
        name = 'Roll',
        text = {
        [1] = '{C:green}1 in 4{} chance to',
        [2] = 'gain {C:attention}+1{} Joker Slot'
    }
    },
    cost = 3,
    unlocked = true,
    discovered = true,
    hidden = false,
    can_repeat_soul = false,
    atlas = 'CustomConsumables',
    use = function(self, card, area, copier)
        local used_card = copier or card
            if SMODS.pseudorandom_probability(card, 'group_0_1c0f793a', 1, card.ability.extra.odds, 'c_badmodog_roll', false) then
                
                G.E_MANAGER:add_event(Event({
                trigger = 'after',
                delay = 0.4,
                func = function()
                    card_eval_status_text(used_card, 'extra', nil, nil, nil, {message = "+"..tostring(1).." Joker Slot", colour = G.C.DARK_EDITION})
                    G.jokers.config.card_limit = G.jokers.config.card_limit + 1
                    return true
                end
            }))
            delay(0.6)
            end
    end,
    can_use = function(self, card)
        return true
    end
}