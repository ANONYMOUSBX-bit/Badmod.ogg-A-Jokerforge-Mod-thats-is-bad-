SMODS.ConsumableType {
    key = 'gambling',
    primary_colour = HEX('ff0000'),
    secondary_colour = HEX('ff0000'),
    collection_rows = { 4, 5 },
    shop_rate = 0,
    cards = {
        ['c_badmodog_bankroll'] = true,
        ['c_badmodog_bet'] = true,
        ['c_badmodog_bluff'] = true,
        ['c_badmodog_bonus'] = true,
        ['c_badmodog_bookie'] = true,
        ['c_badmodog_casino'] = true,
        ['c_badmodog_dealer'] = true,
        ['c_badmodog_roll'] = true
    },
    loc_txt = {
        name = "Gambling",
        collection = "Gambling Cards",
    }
}