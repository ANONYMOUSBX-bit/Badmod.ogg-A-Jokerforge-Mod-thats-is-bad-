SMODS.Shader({ key = 'laminated', path = 'laminated.fs' })

SMODS.Edition {
    key = 'happy',
    shader = 'laminated',
    in_shop = false,
    weight = 1.5,
    extra_cost = 10,
    apply_to_float = false,
    disable_shadow = false,
    disable_base_shader = false,
    loc_txt = {
        name = 'Happy',
        label = 'Happy',
        text = {
        [1] = 'A {C:blue}custom{} edition with {C:red}unique{} effects.'
    }
    },
    unlocked = true,
    discovered = true,
    no_collection = false,
    get_weight = function(self)
        return G.GAME.edition_rate * self.weight
    end,
  
    calculate = function(self, card, context)
        if context.pre_joker or (context.main_scoring and context.cardarea == G.play) and (function()
    for i = 1, #G.jokers.cards do
        if G.jokers.cards[i].config.center.key == "j_joker" then
            return true
        end
    end
    return false
end)() then
        end
    end
}